import requests

GROQ_API_KEY = "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"  # 🔐 Replace with your real API key
GROQ_MODEL = "llama3-8b-8192"
  # or "gemma-7b-it"

def ask_groq(prompt):
    url = "https://api.groq.com/openai/v1/chat/completions"
    
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": GROQ_MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful fraud detection assistant."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7
    }

    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        return response.json()["choices"][0]["message"]["content"]
    else:
        print(f"❌ Error: {response.status_code} - {response.text}")
        return None

# 🚀 Test
result = ask_groq("What are signs of a fraudulent M-Pesa transaction?")
print("Groq says:\n", result)
