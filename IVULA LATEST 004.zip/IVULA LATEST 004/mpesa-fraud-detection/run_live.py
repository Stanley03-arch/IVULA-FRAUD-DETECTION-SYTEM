import asyncio
import httpx
from app.transaction_simulator import fetch_transaction

async def send_transaction(transaction: dict):
    async with httpx.AsyncClient() as client:
        response = await client.post("http://127.0.0.1:8000/analyze", json=transaction)
        response.raise_for_status()
        return response.json()

async def live_simulation():
    while True:
        transaction = await fetch_transaction()
        if transaction:
            result = await send_transaction(transaction)
            print("Transaction:")
            print(transaction)
            print("Result:")
            print(result)
        else:
            print("Failed to generate transaction")
        await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(live_simulation())
