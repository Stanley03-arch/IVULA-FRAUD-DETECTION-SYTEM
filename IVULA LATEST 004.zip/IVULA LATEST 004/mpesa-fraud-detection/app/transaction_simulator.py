from dotenv import load_dotenv
import os
import asyncio
import httpx
import json

load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"  # correct endpoint

async def fetch_transaction():
    if not GROQ_API_KEY:
        print("❌ API Key not loaded. Check your .env file.")
        return None

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }

    system_prompt = "You are an API that generates realistic M-Pesa transactions in JSON."
    user_prompt = (
        "Generate a realistic M-Pesa transaction in JSON with exactly the following keys: "
        "transaction_id (string), sender_id (string), receiver_id (string), amount (number), "
        "timestamp (ISO 8601 string), sender_average (number), "
        "sender_history (list of objects, each with receiver_id (string) and timestamp (ISO 8601 string)), "
        "sender_location (string), receiver_location (string). "
        "Return only the JSON without any extra text."
    )

    data = {
        "model": "llama3-8b-8192",  # Make sure this model is available on Groq
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.7
    }

    async with httpx.AsyncClient(timeout=20.0) as client:
        try:
            response = await client.post(GROQ_URL, headers=headers, json=data)
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            print(f"❌ HTTP error: {e.response.status_code} - {e.response.text}")
            return None
        except Exception as e:
            print("❌ Error fetching transaction:", e)
            return None

    try:
        result = response.json()
        print("✅ Raw Response:", json.dumps(result, indent=2))  # DEBUG
        content = result["choices"][0]["message"]["content"]
        transaction = json.loads(content)
        return transaction
    except Exception as e:
        print("❌ Failed to parse transaction JSON:", e)
        return None

if __name__ == "__main__":
    transaction = asyncio.run(fetch_transaction())
    print("Generated Transaction:", json.dumps(transaction, indent=2) if transaction else "No transaction returned.")
