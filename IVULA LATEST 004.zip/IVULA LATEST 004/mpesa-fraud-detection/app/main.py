from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, RedirectResponse
from app.api.endpoints import router as api_router
from app.api.endpoints_ui import router as ui_router
from pydantic import BaseModel
from typing import List, Optional
from app.services.fraud_detection import analyze_transaction

class TransactionHistory(BaseModel):
    receiver_id: str
    timestamp: str

class Transaction(BaseModel):
    transaction_id: str
    sender_id: str
    receiver_id: str
    amount: float
    timestamp: str
    sender_average: float
    sender_history: List[TransactionHistory]
    sender_location: Optional[str]
    receiver_location: Optional[str]

app = FastAPI()

# Optionally configure CORS if your UI is served from a different origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)
app.include_router(ui_router)

# Mount the static directory for your UI dashboard
app.mount("/dashboard", StaticFiles(directory="app/static", html=True), name="dashboard")

@app.get("/")
async def root():
    return RedirectResponse(url="/dashboard")

@app.get("/dashboard")
async def read_dashboard():
    return FileResponse('app/static/index.html')

@app.get("/dashboard/transactions.html")
async def read_transactions():
    return FileResponse('app/static/transactions.html')

@app.post("/analyze")
def analyze_endpoint(transaction: Transaction):
    result = analyze_transaction(transaction.dict())
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
