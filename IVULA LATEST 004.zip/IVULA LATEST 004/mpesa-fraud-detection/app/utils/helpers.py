def generate_random_transaction():
    import random
    return {
        "amount": random.uniform(1.0, 1000.0),
        "transaction_type": random.choice(["payment", "transfer", "withdrawal"]),
        "timestamp": "2023-10-01T12:00:00Z",
        "user_id": random.randint(1000, 9999),
        "location": random.choice(["Nairobi", "Mombasa", "Kisumu"]),
    }

def format_output(fraud_score, reason):
    return f"Fraud Score: {fraud_score}, Reason: {reason}"