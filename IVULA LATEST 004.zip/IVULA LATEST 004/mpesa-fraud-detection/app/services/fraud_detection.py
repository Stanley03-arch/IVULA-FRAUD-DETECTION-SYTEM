import datetime

def analyze_transaction(transaction: dict) -> dict:
    fraud_score = 0.0
    reasons = []

    # Rule 1: Amount > 2x sender average
    amount = transaction.get("amount", 0)
    sender_average = transaction.get("sender_average", 0)
    if sender_average and amount > 2 * sender_average:
        fraud_score += 0.3
        reasons.append("Amount exceeds 2x sender average")

    # Rule 2: Sender never transacted with receiver before
    sender_history = transaction.get("sender_history", [])
    receiver_id = transaction.get("receiver_id")
    if not any(hist.get("receiver_id") == receiver_id for hist in sender_history):
        fraud_score += 0.3
        reasons.append("Sender has never transacted with receiver before")

    # Rule 3: More than 3 transactions in the last 5 minutes
    current_timestamp_str = transaction.get("timestamp")
    if current_timestamp_str:
        try:
            current_timestamp = datetime.datetime.fromisoformat(current_timestamp_str)
            recent_transactions = 0
            for hist in sender_history:
                hist_timestamp_str = hist.get("timestamp")
                if hist_timestamp_str:
                    hist_timestamp = datetime.datetime.fromisoformat(hist_timestamp_str)
                    if (current_timestamp - hist_timestamp).total_seconds() <= 300:
                        recent_transactions += 1
            if recent_transactions > 3:
                fraud_score += 0.3
                reasons.append("More than 3 transactions in the last 5 minutes")
        except Exception:
            # If timestamp parsing fails, skip the recent transactions check
            pass

    # Rule 4: Different sender and receiver locations
    sender_location = transaction.get("sender_location")
    receiver_location = transaction.get("receiver_location")
    if sender_location and receiver_location and sender_location != receiver_location:
        fraud_score += 0.2
        reasons.append("Sender and receiver are in different locations")

    # Cap fraud score at 1.0
    fraud_score = min(1.0, fraud_score)
    reason_text = "; ".join(reasons) if reasons else "No fraudulent indicators"

    return {
        "fraud_score": fraud_score,
        "reason": reason_text
    }
