from pydantic import BaseModel, Field

class Transaction(BaseModel):
    transaction_id: str = Field(..., description="Unique identifier for the transaction")
    amount: float = Field(..., gt=0, description="Amount of the transaction")
    transaction_type: str = Field(..., description="Type of transaction (e.g., 'payment', 'transfer')")
    timestamp: str = Field(..., description="Timestamp of the transaction in ISO format")
    sender: str = Field(..., description="Identifier for the sender")
    receiver: str = Field(..., description="Identifier for the receiver")
    location: str = Field(..., description="Location where the transaction took place")
    is_fraudulent: bool = Field(default=False, description="Flag indicating if the transaction is suspected to be fraudulent")