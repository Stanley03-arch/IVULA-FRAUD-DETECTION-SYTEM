from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.fraud_detection import analyze_transaction

router = APIRouter()

class Transaction(BaseModel):
    transaction_id: str
    amount: float
    timestamp: str
    sender: str
    receiver: str
    transaction_type: str

@router.post("/analyze")
async def analyze(transaction: Transaction):
    try:
        result = analyze_transaction(transaction.model_dump())
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
