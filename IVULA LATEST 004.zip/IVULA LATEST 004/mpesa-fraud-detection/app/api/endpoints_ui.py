import sqlite3
import random
import numpy as np
import joblib
from fastapi import APIRouter, HTTPException, status, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from app.transaction_simulator import fetch_transaction
from app.services.fraud_detection import analyze_transaction

router = APIRouter()

# ----------------------------
# Initialize SQLite database
# ----------------------------
DB_PATH = "transactions.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    transaction_id TEXT,
                    sender_id TEXT,
                    receiver_id TEXT,
                    amount REAL,
                    timestamp TEXT,
                    fraud_probability REAL,
                    reason TEXT
                )''')
    conn.commit()
    conn.close()

# Call DB initialization at startup
init_db()

def log_transaction(txn: dict, analysis: dict):
    """Insert a transaction log into the SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''INSERT INTO transactions (transaction_id, sender_id, receiver_id, amount, timestamp, fraud_probability, reason)
                 VALUES (?, ?, ?, ?, ?, ?, ?)''',
                 (txn.get("transaction_id"),
                  txn.get("sender_id"),
                  txn.get("receiver_id"),
                  txn.get("amount"),
                  txn.get("timestamp"),
                  float(analysis.get("fraud_probability", 0)),
                  analysis.get("reason", "N/A")))
    conn.commit()
    conn.close()

# ----------------------------
# WebSocket Connection Manager
# ----------------------------
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
    
    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

manager = ConnectionManager()

# ----------------------------
# Load the LightGBM model.
# ----------------------------
try:
    model = joblib.load("lgb_fraud_model.joblib")
except Exception as e:
    model = None
    print(f"Warning: Could not load LightGBM model: {e}")

# Pydantic model for the /predict endpoint
class TransactionData(BaseModel):
    amount: float
    time_diff: float
    sender_age: int
    receiver_age: int

@router.post("/predict")
def predict(transaction: TransactionData):
    """
    Predict fraud probability using the trained LightGBM model.
    """
    if not model:
        raise HTTPException(status_code=500, detail="Machine learning model not available")
    features = np.array([[transaction.amount, transaction.time_diff, transaction.sender_age, transaction.receiver_age]])
    proba = model.predict(features)[0]
    return {"fraud_probability": float(proba)}

@router.get("/simulate")
async def simulate():
    """
    Simulate a transaction using our existing synthetic data generator and analyze it.
    """
    txn = await fetch_transaction()
    if not txn:
        return {"error": "Failed to fetch transaction"}
    analysis = analyze_transaction(txn)
    return {"transaction": txn, "analysis": analysis}

@router.post("/stop")
async def stop_transaction(payload: dict):
    """
    Block a transaction. Currently, this endpoint simply returns an acknowledgment.
    """
    transaction_id = payload.get("transaction_id")
    if not transaction_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing transaction ID")
    # Logic to block the transaction can be added here.
    return {"message": f"Transaction {transaction_id} has been blocked by the AI."}
