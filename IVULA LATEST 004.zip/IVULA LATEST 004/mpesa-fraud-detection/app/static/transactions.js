document.addEventListener('DOMContentLoaded', () => {
    fetchTransactions();
});

async function fetchTransactions() {
    try {
        const response = await fetch('/transactions');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        if (data.error) {
            displayError(data.error);
        } else {
            updateTransactionsTable(data.transactions);
        }
    } catch (error) {
        console.error('Error fetching transactions:', error);
        displayError('Error loading transactions');
    }
}

function updateTransactionsTable(transactions) {
    const tableBody = document.querySelector('#transactionsTable tbody');
    if (!tableBody) return;
    // Clear current table content
    tableBody.innerHTML = '';
    // Populate table rows with each recorded transaction
    transactions.forEach(t => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${t.transaction_id}</td>
            <td>${t.sender_id}</td>
            <td>${t.receiver_id}</td>
            <td>${t.amount}</td>
            <td>${t.timestamp}</td>
            <td>${t.fraud_probability}</td>
            <td>${t.reason}</td>
            <td>
              ${t.fraud_probability >= 0.7
                   ? `<button class="block-btn" onclick="blockTransaction('${t.transaction_id}')">Block Transaction</button>`
                   : 'N/A' }
            </td>
        `;
        tableBody.appendChild(tr);
    });
}

function displayError(message) {
    const tableBody = document.querySelector('#transactionsTable tbody');
    if (!tableBody) return;
    tableBody.innerHTML = `<tr><td colspan="8">${message}</td></tr>`;
}

async function blockTransaction(transactionId) {
    try {
        const response = await fetch('/stop', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ transaction_id: transactionId })
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error blocking transaction:', error);
        alert('Failed to block transaction.');
    }
}
