let allTransactions = [];

async function fetchData() {
    try {
        const response = await fetch('/simulate');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        if(data.error) {
            displayError(data.error);
        } else {
            updateDashboard(data);
            storeTransaction(data);
            updateTransactionsTable();
        }
    } catch (error) {
        console.error('Error fetching simulation data:', error);
        displayError('Error loading data');
    }
}

function displayError(message) {
    if(document.getElementById('transactionData')) {
        document.getElementById('transactionData').textContent = message;
    }
    if(document.getElementById('analysisData')) {
        document.getElementById('analysisData').textContent = message;
    }
}

function updateDashboard(data) {
    if(document.getElementById('transactionData')) {
        document.getElementById('transactionData').textContent = JSON.stringify(data.transaction, null, 2);
    }
    if(document.getElementById('analysisData')) {
        document.getElementById('analysisData').textContent = JSON.stringify(data.analysis, null, 2);
    }
}

function storeTransaction(data) {
    // record each new transaction with its analysis
    allTransactions.push({
        transaction: data.transaction,
        analysis: data.analysis
    });
}

function updateTransactionsTable() {
    const tableBody = document.querySelector('#transactionsTable tbody');
    if (!tableBody) return;
    // Clear current table content
    tableBody.innerHTML = '';
    // Populate table rows with each recorded transaction
    allTransactions.forEach(item => {
        const t = item.transaction;
        const a = item.analysis;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${t.transaction_id}</td>
            <td>${t.sender_id}</td>
            <td>${t.receiver_id}</td>
            <td>${t.amount}</td>
            <td>${t.timestamp}</td>
            <td>${a.fraud_score}</td>
            <td>${a.reason}</td>
            <td>
              ${a.fraud_score >= 0.7 
                   ? `<button class="block-btn" onclick="blockTransaction('${t.transaction_id}')">Block Transaction</button>`
                   : 'N/A' }
            </td>
        `;
        tableBody.appendChild(tr);
    });
}

async function blockTransaction(transactionId) {
    try {
        const response = await fetch('/stop', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ transaction_id: transactionId })
        });
        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error blocking transaction:', error);
        alert('Failed to block transaction.');
    }
}

// Fetch data immediately and then every 5 seconds
fetchData();
setInterval(fetchData, 5000);
