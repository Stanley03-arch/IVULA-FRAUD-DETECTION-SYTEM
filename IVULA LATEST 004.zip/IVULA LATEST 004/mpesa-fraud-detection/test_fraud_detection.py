from app.services.fraud_detection import analyze_transaction
import datetime

# Create a sample transaction
now = datetime.datetime.now().isoformat()
earlier = (datetime.datetime.now() - datetime.timedelta(minutes=4)).isoformat()

sample_transaction = {
    "transaction_id": "tx123",
    "sender_id": "sender1",
    "receiver_id": "receiver1",
    "amount": 500,
    "timestamp": now,
    "sender_average": 200,
    "sender_history": [
        {"receiver_id": "receiver2", "timestamp": earlier},
        {"receiver_id": "receiver3", "timestamp": earlier},
        {"receiver_id": "receiver4", "timestamp": earlier},
        {"receiver_id": "receiver5", "timestamp": earlier},
    ],
    "sender_location": "Nairobi",
    "receiver_location": "Mombasa"
}

result = analyze_transaction(sample_transaction)
print(result)