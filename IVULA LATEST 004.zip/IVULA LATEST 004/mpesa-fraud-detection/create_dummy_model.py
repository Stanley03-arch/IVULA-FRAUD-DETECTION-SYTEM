import joblib
from sklearn.linear_model import LogisticRegression

# Create a dummy model
dummy_model = LogisticRegression()

# Save the dummy model to a file
joblib.dump(dummy_model, 'lgb_fraud_model.joblib')

print("Dummy model 'lgb_fraud_model.joblib' created successfully.")
