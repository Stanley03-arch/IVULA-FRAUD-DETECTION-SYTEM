# M-Pesa Fraud Detection MVP

This project is a FastAPI application designed to detect potential fraud in M-Pesa transactions in real-time. It provides an API endpoint to analyze transactions and return a fraud score along with the reasoning behind the score.

## Features

- **Real-time Fraud Detection**: Analyze transactions as they occur to identify potential fraud.
- **API Endpoint**: A POST endpoint `/analyze` that accepts transaction data and returns a fraud score and reason.
- **Data Validation**: Utilizes Pydantic models to ensure incoming transaction data is valid.
- **Modular Structure**: Organized into separate modules for API endpoints, models, services, and utilities.

## Project Structure

```
mpesa-fraud-detection
├── app
│   ├── main.py               # Entry point of the FastAPI application
│   ├── api
│   │   └── endpoints.py      # API endpoints definition
│   ├── models
│   │   └── transaction.py     # Data model for transactions
│   ├── services
│   │   └── fraud_detection.py # Core fraud detection logic
│   └── utils
│       └── helpers.py        # Utility functions
├── tests
│   └── test_endpoints.py     # Unit tests for API endpoints
├── requirements.txt           # Project dependencies
└── README.md                  # Project documentation
```

## Setup Instructions

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd mpesa-fraud-detection
   ```

2. **Create a Virtual Environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the Application**:
   ```bash
   uvicorn app.main:app --reload
   ```

5. **Access the API**:
   The API will be available at `http://127.0.0.1:8000`. You can test the `/analyze` endpoint using tools like Postman or curl.

## Usage

To analyze a transaction, send a POST request to the `/analyze` endpoint with the transaction data in JSON format. The response will include the fraud score and the reason for the score.

## Testing

To run the tests, ensure you have `pytest` installed, then execute:

```bash
pytest tests/test_endpoints.py
```

This will run the unit tests defined for the API endpoints to ensure they function as expected.